// This file is no longer used - replaced with discord-youtube-dl streaming system
console.log('🎵 Lavalink has been replaced with discord-youtube-dl streaming system');

module.exports = null;